<?php
require __DIR__ . '/inc/app.php';

// TODO 5B: Türsteher – nur angemeldete Benutzer dürfen hierher, sonst weiter zu login.php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $points = evaluate($_POST);
    // TODO 5B: Den Namen aus der Session nehmen statt "Gast"
    add_score('Gast', $points);
    page_header('Resultat');
    ?>
    <div class="card">
        <h1><?= $points ?> von <?= count(QUESTIONS) ?> Punkten</h1>
        <p>Gespeichert als <strong>Gast</strong> – der Server weiss noch nicht, wer du bist.</p>
        <a class="btn" href="quiz.php">Nochmals</a>
    </div>
    <?php
    page_footer();
    exit;
}

page_header('Quiz');
?>
<form action="quiz.php" method="post">
    <?php foreach (QUESTIONS as $i => [$text, $options]): ?>
        <div class="card">
            <p><strong><?= $i + 1 ?>. <?= e($text) ?></strong></p>
            <?php foreach ($options as $j => $option): ?>
                <label><input type="radio" name="q<?= $i ?>" value="<?= $j ?>"> <?= e($option) ?></label>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
    <button class="btn" type="submit">Auswerten</button>
</form>
<?php
page_footer();

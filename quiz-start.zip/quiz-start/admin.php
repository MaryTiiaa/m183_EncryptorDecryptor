<?php
require __DIR__ . '/inc/app.php';

// TODO 5B: Türsteher – nur die Rolle ADMIN darf hierher, alle anderen bekommen 403

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    clear_scores();
    header('Location: admin.php');
    exit;
}

$scores = load_scores();
page_header('Admin');
?>
<div class="card">
    <h1>Highscores</h1>
    <table>
        <tr><th>Name</th><th>Punkte</th></tr>
        <?php foreach ($scores as $s): ?>
            <tr><td><?= e($s['name']) ?></td><td><?= (int) $s['points'] ?> / <?= (int) $s['max'] ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$scores): ?><tr><td colspan="2">Noch keine Einträge.</td></tr><?php endif; ?>
    </table>
    <form action="admin.php" method="post" style="margin-top:14px">
        <button class="btn" type="submit">Alle Highscores löschen</button>
    </form>
</div>
<?php
page_footer();

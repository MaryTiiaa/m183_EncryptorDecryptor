<?php
/**
 * Login – das Passwort wird schon korrekt geprüft (bcrypt), aber danach passiert NICHTS:
 * Der Server "vergisst" sofort wieder, wer sich angemeldet hat. Genau das löst ihr in SideQuest 5B.
 */
require __DIR__ . '/inc/app.php';

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = check_login((string) ($_POST['username'] ?? ''), (string) ($_POST['password'] ?? ''));
    if ($user) {
        // TODO 5B: Session starten, Benutzer darin merken, Cookie mit allen Flags setzen
        //          (Flags: HttpOnly, Secure, SameSite, Path, Lebensdauer – und neue Session-ID!)
        header('Location: quiz.php');
        exit;
    }
    $error = 'Benutzername oder Passwort falsch.';
}

page_header('Login');
?>
<div class="card">
    <h1>Login</h1>
    <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
    <form action="login.php" method="post">
        <label>Benutzername <input type="text" name="username" autocomplete="username" required></label>
        <label>Passwort <input type="password" name="password" autocomplete="current-password" required></label>
        <button class="btn" type="submit">Anmelden</button>
    </form>
</div>
<?php
page_footer();

<?php
require __DIR__ . '/inc/app.php';

page_header('Start');
?>
<div class="card">
    <h1>Willkommen beim WISS Quiz</h1>
    <p>Acht Fragen rund um Krypto, Cookies und Tokens. Das Quiz und die Highscore-Verwaltung
       sollen nur nach dem Login erreichbar sein – noch sind sie offen.</p>
    <a class="btn" href="quiz.php">Quiz starten</a>
</div>
<div class="card hint">Testkonten: <code>alice / quiz2026</code> (USER) · <code>admin / admin2026</code> (ADMIN)</div>
<?php
page_footer();

<?php
/**
 * WISS Quiz – gemeinsame Bausteine: Fragen, Benutzer, Highscores, Layout.
 * Läuft mit PHP 8.0+ (XAMPP aus dem Software-Kiosk). Keine Datenbank nötig.
 */
declare(strict_types=1);

// ------------------------------------------------------------------ Fragen

const QUESTIONS = [
    ['Was ist Base64?', ['Verschlüsselung', 'Encoding', 'Hash'], 1],
    ['Womit speichert man Passwörter?', ['AES', 'Base64', 'Langsamer Hash mit Salt (z.B. bcrypt)'], 2],
    ['Welches Cookie-Flag verhindert Zugriff per JavaScript?', ['Secure', 'HttpOnly', 'SameSite'], 1],
    ['Welches Cookie-Flag sorgt dafür, dass das Cookie nur über HTTPS reist?', ['Secure', 'Path', 'Max-Age'], 0],
    ['Wofür hilft SameSite=Lax vor allem?', ['Gegen CSRF', 'Gegen SQL-Injection', 'Gegen Brute Force'], 0],
    ['Welcher Teil eines JWT schützt vor Manipulation?', ['Header', 'Payload', 'Signatur'], 2],
    ['Ist der Payload eines JWT verschlüsselt?', ['Ja, immer', 'Nein, nur Base64URL-kodiert', 'Nur mit HttpOnly'], 1],
    ['Welche OWASP-Kategorie 2025 betrifft Login und Sessions?', ['A01 Broken Access Control', 'A07 Authentication Failures', 'A05 Injection'], 1],
];

function evaluate(array $answers): int
{
    $points = 0;
    foreach (QUESTIONS as $i => $q) {
        if (isset($answers["q$i"]) && (string) $answers["q$i"] === (string) $q[2]) {
            $points++;
        }
    }
    return $points;
}

// ------------------------------------------------------------------ Benutzer

/**
 * Testkonten:  alice / quiz2026 (USER)  ·  admin / admin2026 (ADMIN)
 * Gespeichert sind nur bcrypt-Hashes (vgl. Block 4), nie die Passwörter selbst.
 */
const USERS = [
    'alice' => ['hash' => '$2y$10$afynrjRkG6MLWG8kLVmEQu.dgBDc9d3TkhaoKiDwjHqviBSaC2oLO', 'role' => 'USER'],
    'admin' => ['hash' => '$2y$10$qf46hiIQ5w/ZaApn3U/ge.Lulm6tsnsmEQrpq4gRfjtFi0nzTAHhS', 'role' => 'ADMIN'],
];

/** Liefert ['username' => …, 'role' => …] nur bei korrektem Passwort, sonst null. */
function check_login(string $username, string $password): ?array
{
    if (!isset(USERS[$username]) || !password_verify($password, USERS[$username]['hash'])) {
        return null;
    }
    return ['username' => $username, 'role' => USERS[$username]['role']];
}

// ------------------------------------------------------------------ Highscores (JSON-Datei)

const SCORE_FILE = __DIR__ . '/../data/scores.json';

function load_scores(): array
{
    if (!is_file(SCORE_FILE)) {
        return [];
    }
    $scores = json_decode((string) file_get_contents(SCORE_FILE), true) ?: [];
    usort($scores, fn($a, $b) => $b['points'] <=> $a['points']);
    return $scores;
}

function add_score(string $name, int $points): void
{
    $scores = load_scores();
    $scores[] = ['name' => $name, 'points' => $points, 'max' => count(QUESTIONS)];
    file_put_contents(SCORE_FILE, json_encode($scores), LOCK_EX);
}

function clear_scores(): void
{
    file_put_contents(SCORE_FILE, '[]', LOCK_EX);
}

// ------------------------------------------------------------------ Layout

/** Jede Ausgabe von Daten geht durch e() – Schutz gegen XSS (Block 2). */
function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function page_header(string $title, ?array $user = null): void
{
    ?><!DOCTYPE html>
<html lang="de-CH">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · WISS Quiz</title>
    <link rel="stylesheet" href="quiz.css">
</head>
<body>
<header>
    <b>WISS Quiz</b>
    <a href="index.php">Start</a>
    <a href="quiz.php">Quiz</a>
    <a href="admin.php">Admin</a>
    <?php if ($user): ?>
        <span>Angemeldet: <strong><?= e($user['username']) ?></strong>
            <form action="logout.php" method="post" style="display:inline"><button type="submit">· Logout</button></form>
        </span>
    <?php else: ?>
        <a href="login.php">Login</a>
    <?php endif; ?>
</header>
<main>
<?php
}

function page_footer(): void
{
    echo "</main>\n</body>\n</html>\n";
}

<?php
require __DIR__ . '/inc/app.php';

// TODO 5B: Session auf dem Server löschen UND Cookie im Browser löschen

header('Location: index.php');
exit;
